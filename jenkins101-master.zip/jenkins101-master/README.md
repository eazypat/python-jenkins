# jenkins101
A Python script that uses Jenkins' API to get a list of jobs and their status from a given jenkins instance. The status for each job is stored in an sqlite database along with the time for when it was checked.
